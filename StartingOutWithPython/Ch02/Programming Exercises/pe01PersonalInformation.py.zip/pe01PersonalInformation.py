print('Daniyal')
print('123 Main Street, New York City, New York, 18989')
print('555-349-8618')
print('Computer Science')

"""
OUTPUT

Daniyal
123 Main Street, New York City, New York, 18989
555-349-8618
Computer Science
"""